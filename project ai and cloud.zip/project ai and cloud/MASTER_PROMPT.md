# Master Prompt: End-to-End Containerization & Kubernetes Deployment

## Objective
Take any full-stack application project (zipped or existing) that requires a backend service and MongoDB data storage, and deploy it locally using Docker and Kubernetes (Minikube). The application must successfully connect to MongoDB and be accessible via a browser.

---

## Phase 1: Project Preparation

1. **Extract & Inspect**
   - Extract the zipped project into a folder matching the project name.
   - Navigate into the project root.
   - Verify the presence of dependency manifest files (e.g., `package.json`, `requirements.txt`, `pom.xml`, etc.).
   - Verify the presence of an entry-point server file (e.g., `server.js`, `app.js`, `app.py`, etc.).
   - If the entry-point file is missing, create a minimal web server that:
     - Serves static files from a `public/` or `static/` directory.
     - Exposes a health-check endpoint (e.g., `GET /health`).
     - Attempts to connect to MongoDB using an environment-variable-based connection string.

2. **Dependency Check**
   - Ensure the MongoDB database driver/library is listed in the dependency manifest.
   - Add it if absent (e.g., `pymongo`, `mongoose`, `mongodb`, etc.).

---

## Phase 2: Docker Containerization

1. **Create / Update Dockerfile**
   Use a lightweight base image appropriate for the runtime (e.g., `node:18-alpine`, `python:3.12-slim`).
   The Dockerfile must:
   - Set a working directory (e.g., `/app`).
   - Copy dependency manifests first and install dependencies (leverage layer caching).
   - Copy the remaining application source code.
   - Expose the application port (e.g., `3000`, `8501`, `8080`).
   - Define the startup command (e.g., `node server.js`, `streamlit run app.py`, `python app.py`).

2. **Local Docker Test**
   ```bash
   docker build -t <app-image-name> .
   docker run -p <host-port>:<container-port> <app-image-name>
   ```
   - Confirm the container starts without errors.
   - Confirm the health endpoint responds.

---

## Phase 3: Kubernetes Manifests

### 3.1 Deployment (`deployment.yaml`)
Create a Deployment resource with the following specifications:
- **Replicas:** `2`
- **Pod Spec:** Two containers per pod:
  1. **Application Container**
     - Image: the locally built image tag (e.g., `<app-image-name>:latest`).
     - Image pull policy: `Never` (for local Minikube builds) or `IfNotPresent`.
     - Container port matching the application port.
     - Environment variables:
       - `MONGO_URI` (pointing to the sidecar MongoDB, e.g., `mongodb://localhost:27017`)
       - Any API keys or secrets required by the application.
     - Resource requests/limits (memory and CPU).
  2. **MongoDB Container**
     - Image: `mongo:latest` (or a pinned version).
     - Container port: `27017`.
     - Environment variables for initialization if needed (e.g., `MONGO_INITDB_DATABASE`).
     - A volume mounted at `/data/db` for persistence (use `emptyDir` for local Minikube; use `PersistentVolumeClaim` for production).
     - Resource requests/limits.

### 3.2 Services (`service.yaml`)
Create two Service resources:

1. **Application Service (NodePort)**
   - Type: `NodePort`
   - Selector labels matching the Deployment labels.
   - Ports:
     - `port`: application port
     - `targetPort`: application container port
     - `nodePort`: a fixed high port (e.g., `30007`)

2. **Database Service (ClusterIP)**
   - Type: `ClusterIP`
   - Selector labels matching the Deployment labels.
   - Ports:
     - `port`: `27017`
     - `targetPort`: `27017`

---

## Phase 4: Minikube Setup & Deployment

### 4.1 Start Minikube
```bash
minikube start --driver=docker
```

### 4.2 Configure Docker for Minikube
Point the local Docker CLI to Minikube’s internal Docker daemon so images are available inside the cluster without a registry:

- **Windows (PowerShell):**
  ```powershell
  minikube docker-env | Invoke-Expression
  ```
- **macOS / Linux (Bash/Zsh):**
  ```bash
  eval $(minikube docker-env)
  ```

### 4.3 Build Image Inside Minikube Context
```bash
docker build -t <app-image-name>:latest .
```

### 4.4 Apply Manifests
```bash
kubectl apply -f k8s/
```

### 4.5 Verify State
```bash
kubectl get pods
kubectl get services
kubectl get deployments
```
- Ensure pods reach `Running` status with all containers ready (e.g., `2/2`).
- Ensure services show correct types, cluster IPs, and node ports.

---

## Phase 5: Access & Validation

1. **Open the Application**
   ```bash
   minikube service <app-service-name>
   ```
   This should automatically launch the default browser to the correct NodePort URL.

2. **Functional Checks**
   - Confirm the application UI/API loads in the browser.
   - Perform an operation that triggers a database read/write.
   - Verify data persists or is retrieved successfully (MongoDB connection is healthy).

---

## Phase 6: Automatic Debugging

If any step fails, execute the following diagnostic flow:

1. **Pod Status**
   ```bash
   kubectl get pods
   kubectl describe pod <pod-name>
   ```
   - Look for `ImagePullBackOff`, `CrashLoopBackOff`, or `Pending` states.

2. **Container Logs**
   ```bash
   kubectl logs <pod-name> -c <app-container-name>
   kubectl logs <pod-name> -c <mongo-container-name>
   ```

3. **Live Connection Test**
   Exec into the application container and test the MongoDB connection directly:
   ```bash
   kubectl exec -it <pod-name> -c <app-container-name> -- /bin/sh
   # Inside container, run language-specific MongoDB ping/connection test
   ```

4. **Common Fixes**
   - **ImagePullBackOff:** Re-run `minikube docker-env` setup and rebuild the image.
   - **Connection refused / timeout:** Verify the `MONGO_URI` uses `localhost` (or the correct in-pod reference) and that the MongoDB container is running before the app initializes. Add retry logic in the application if needed.
   - **OOMKilled / Evicted:** Increase memory limits in the Deployment manifest or allocate more RAM to Minikube (`minikube start --driver=docker --memory=4096`).
   - **Port conflicts:** Ensure the chosen NodePort (e.g., `30007`) is not already in use on the host.

5. **Rolling Restart**
   ```bash
   kubectl rollout restart deployment/<deployment-name>
   ```

---

## Phase 7: Teardown (Optional)

```bash
kubectl delete -f k8s/
minikube stop
```

---

## Deliverables Checklist

- [ ] Dockerfile present and builds successfully.
- [ ] `deployment.yaml` with 2 replicas, app container + MongoDB container.
- [ ] `service.yaml` with NodePort for app (port mapped to a fixed NodePort) and ClusterIP for MongoDB.
- [ ] Image built inside Minikube Docker context.
- [ ] Pods show `Running` and `2/2` Ready.
- [ ] Services show correct types and ports.
- [ ] Application opens in browser via `minikube service`.
- [ ] Application successfully connects to MongoDB and demonstrates data persistence.

---

## Notes

- This prompt is runtime-agnostic: replace Node.js/Python/Go specifics as needed, but keep the structural requirements (manifests, sidecar pattern, environment variables, Minikube workflow).
- For production, replace `emptyDir` with a `PersistentVolumeClaim`, use a private image registry, and add Secrets/ConfigMaps for sensitive data.

