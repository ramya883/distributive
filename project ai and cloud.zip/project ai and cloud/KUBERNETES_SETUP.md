# Kubernetes Setup Guide (Windows + Minikube)

## Prerequisites
- Docker Desktop installed and running
- Minikube installed (via Chocolatey or installer)
- kubectl installed

---

## Step 1: Start Minikube
Open PowerShell and run:
```powershell
minikube start --driver=docker
```

---

## Step 2: Point Docker to Minikube's Registry
Run this in PowerShell so the Docker build goes into Minikube's local registry:
```powershell
minikube docker-env | Invoke-Expression
```

---

## Step 3: Build the Docker Image
```powershell
docker build -t ai-resume-app:latest .
```

---

## Step 4: Apply Kubernetes Manifests
```powershell
kubectl apply -f k8s/
```

---

## Step 5: Verify Pods are Running
```powershell
kubectl get pods
```
Wait until all pods show `Running` and `2/2` READY.

If a pod is stuck, check events:
```powershell
kubectl describe pod <pod-name>
```

---

## Step 6: Verify Services
```powershell
kubectl get services
```
You should see:
- `ai-resume-app-service` of type `NodePort` on port `30007`
- `mongo-service` of type `ClusterIP` on port `27017`

---

## Step 7: Open the Application
```powershell
minikube service ai-resume-app-service
```
This will open your default browser to the app.

---

## Debugging MongoDB Connection Issues

### 1. Check container logs
```powershell
kubectl logs <pod-name> -c ai-resume-app
kubectl logs <pod-name> -c mongo
```

### 2. Test connection from inside the pod
```powershell
kubectl exec -it <pod-name> -c ai-resume-app -- /bin/sh
# Inside container:
python -c "from pymongo import MongoClient; c=MongoClient('mongodb://localhost:27017', serverSelectionTimeoutMS=5000); c.admin.command('ping'); print('MongoDB connection OK')"
```

### 3. Ensure both containers are running
The pod should show `2/2` in the READY column.

### 4. Restart deployment if needed
```powershell
kubectl rollout restart deployment/ai-resume-portfolio-deployment
```

### 5. Common fixes
- If `ImagePullBackOff`, ensure you ran `minikube docker-env | Invoke-Expression` before `docker build`.
- If MongoDB connection times out, verify the `mongo` container started first. The app will retry on next Streamlit interaction.

---

## Teardown
To delete everything:
```powershell
kubectl delete -f k8s/
minikube stop
```

