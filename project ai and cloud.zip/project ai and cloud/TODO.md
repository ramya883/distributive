# TODO - Kubernetes & Docker Adaptation for AI Resume Builder

- [ ] Step 1: Add `pymongo` to `requirements.txt`
- [ ] Step 2: Update `app.py` with MongoDB persistence logic
- [ ] Step 3: Ensure `Dockerfile` is correct for port 8501
- [ ] Step 4: Create `k8s/deployment.yaml` (2 replicas, app + mongo containers)
- [ ] Step 5: Create `k8s/service.yaml` (NodePort 30007 for app, ClusterIP for MongoDB)
- [ ] Step 6: Create `KUBERNETES_SETUP.md` with Windows/Minikube runbook
- [ ] Step 7: Build Docker image inside Minikube context
- [ ] Step 8: Apply Kubernetes manifests
- [ ] Step 9: Verify pods and services
- [ ] Step 10: Open application via `minikube service`

